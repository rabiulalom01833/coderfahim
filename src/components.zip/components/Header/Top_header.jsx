import React from 'react';

import {Container, Row, Col, ListGroup } from 'react-bootstrap';

import { FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram, FaPinterestP } from "react-icons/fa";
 
import './header.css';

function Top_header() {
    return (
        <div className="header-area">
            <Container> 
                <Row>
                    <Col xs={12} md={6}>
                        <div className="header-left">
			                <ul className="d-flex">
			                    <li>Call Us: 555-444-6666</li> 
			                    <li>Email: support@domain.com</li>
			                </ul>
			            </div>
                    </Col> 
                    <Col xs={12} md={6}>
                        <ul className="social-list ">
                            <li><a href=""><FaFacebookF/></a></li>
                            <li><a href=""><FaTwitter/></a></li>
                            <li><a href=""><FaLinkedinIn/></a></li>
                            <li><a href=""><FaInstagram/></a></li>
                            <li><a href=""><FaPinterestP/></a></li> 
                        </ul> 
                    </Col> 
                </Row>
            </Container>
        </div>
    )
}

export default Top_header
