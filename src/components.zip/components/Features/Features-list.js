

const FeaturesLis = [
    {
        id: 1,
        images: "https://fahim.trinetdigital.com/images/fb1.png",
        titles: "First slide label",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 2,
        images: "https://fahim.trinetdigital.com/images/fb2.png",
        titles: "Second slide label",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 3,
        images: "https://fahim.trinetdigital.com/images/fb3.png",
        titles: "Third slide label",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 4,
        images: "https://fahim.trinetdigital.com/images/fb4.png",
        titles: "Following Instructions",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 5,
        images: "https://fahim.trinetdigital.com/images/fb5.png",
        titles: "Plan Generating",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 6,
        images: "https://fahim.trinetdigital.com/images/fb6.png",
        titles: "Great Finishing",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },

]
export default FeaturesLis;