const BlogLis = [
    {
        id: 1,
        images: "https://fahim.trinetdigital.com/images/1.png",
        titles: "UI & UX Design",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 2,
        images: "https://fahim.trinetdigital.com/images/2.png",
        titles: "Prototype Design",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 3,
        images: "https://fahim.trinetdigital.com/images/3.png",
        titles: "Website Design",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    } 

]
export default BlogLis;