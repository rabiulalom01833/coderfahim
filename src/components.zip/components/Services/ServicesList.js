const ServicesLis = [
    {
        id: 1,
        images: "https://fahim.trinetdigital.com/images/sb1.png",
        titles: "UI & UX Design",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 2,
        images: "https://fahim.trinetdigital.com/images/sb2.png",
        titles: "Prototype Design",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 3,
        images: "https://fahim.trinetdigital.com/images/sb3.png",
        titles: "Website Design",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 4,
        images: "https://fahim.trinetdigital.com/images/sb4.png",
        titles: "Brand Development",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 5,
        images: "https://fahim.trinetdigital.com/images/sb5.png",
        titles: "Vertual Assistant",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },
    {
        id: 6,
        images: "https://fahim.trinetdigital.com/images/sb6.png",
        titles: "Software Development",
        description: 'Natus error sit voluptatem accusantium dolore laudantium, totam eaque ipsa quae ab illo inv ukko ntore veritatis et quasi architec.'
    },

]
export default ServicesLis;