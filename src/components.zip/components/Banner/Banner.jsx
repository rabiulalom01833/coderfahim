import React from 'react';
import {Col, Container, Row, Button } from 'react-bootstrap';

import '../Banner/banner.css';

function Banner() {
    return (
        <div className="banner-area">
            <Container>
                <Row className="justify-content-md-center">
                    <Col lg={6} >
                        <div className="banner-content text-center">
                            <h5>WE ARE CREATIVE AND DEDICATED</h5>
                            <h1 className="title">Your Business Profit Dream</h1>
                            <p>Perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore
                            laudtium, totam rem aperiam, eaque ipsa quae inventore verit.</p>
                            
                            <a href="#" className="theme-btn btn-md">Portfolio</a>{' '} 
                            <a href="#" className="theme-btn btn-md outline-btn">Contact Us</a>  
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default Banner
