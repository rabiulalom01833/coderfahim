import React from 'react';
import { Container, Row, Col, Image } from 'react-bootstrap';
 
import AboutImg from '../../assets/img/about-bg.png';

import './aboutStyle.css';

const About = () => {
    return (
        <div className="about-area section-bgc position-relative" id="about">
            <Image src={AboutImg} className="about-img" />
            <Container>
                <Row>
                    <Col lg={{ span: 6, offset: 6 }}>
                        <div className="about-content pp-100">
                            <h2 className="title pb-2">About Us</h2>
                            <h6 className="title-description">Natus error sit voluptatem accusantium doloremque laudanti um, totam eaque ipsa quae ab illo inventore veritatis.</h6>
                            <p>Accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium volupt atum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p>
                            <p>Actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is plea sure, but because those who do not know how to pursue pleasure.</p>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default About
